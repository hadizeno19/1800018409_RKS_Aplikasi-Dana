<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION['username'])) {
   header('location:dashboard.php'); 
} else { 
   $username = $_SESSION['username']; 
} 
?>
<style>
input[type=text] {
  width: 280px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-image: url('kepo.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 10px 12px 12px 12px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}
</style>
<html>
<head>
	<title>Voucher Game Online</title>
   <link rel="stylesheet" type="text/css" href="css/cssku.css">
  <link rel="stylesheet" type="text/css" href="css/w3.css">
  <link rel="stylesheet" type="text/css" href="css/navbar.css">
  <link rel="stylesheet" type="text/css" href="css/alert.css">
  <link rel="stylesheet" type="text/css" href="css/alert.css">
</head>
<body>

<div class="header">
  <h1>APLIKASI DANA</h1>
  <p>Muhammad Hadi | 1800018409</p>
  <marquee><p>HI Guys</p></marquee>
</div>

<div class="topnav">
  <a href="index.php">Beranda</a>
  <a href="#" id="topupsaldo">Isi Saldo</a>
  <a href="#" id="tfsaldo">Transfer Saldo</a>
  <a href="#" id="voucher">Voucher Game Online</a>
    <a href="logout.php" style="float:right">LOGOUT</a>
</div>
  
<div class="row">
     <div id="content">
  <div class="leftcolumn">
    <div class="card">
    <div class="alert info">
           <h3>Hai selamat datang Nikmati belanja voucher game online murah hanya di <b>Aplikasi Dana</b>.</h3>
     </div>
    </div></div>

  <div class="rightcolumn">
    <div class="card">
      <h2>About Me</h2>
      <div id="fb-root"></div>
     <div class="fb-page" 
  data-href="https://web.facebook.com/Zeno-Zeno-2194277944168253/?ref=settings"
  data-width="380" 
  data-hide-cover="false"
  data-show-facepile="false"></div>
  <marquee><p>Jangan Lupa Follow Fanspage Kami Yaa :)</p></marquee>
    </div>
    <div class="card">
      <h3>List Menu</h3>
      <ul>
  <li><a class="active" href="#" id="voucher">Voucher Game Online</a>
  <li><a href="#">Tiket Pesawat</a></li>
  <li><a href="#">Tiket Kereta</a></li>
  <li><a href="#">Tiket Bus</a></li>
</li>
</div>
</div>
</div>
</div>
<div class="footer">
  <h2>Zeno | 2019</h2>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="proses.js"></script>
<script type="text/javascript" src="submit.js"></script>
<script type="text/javascript" src="js/login.js"></script>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v3.3&appId=825300440918276&autoLogAppEvents=1"></script>
</body>
</html>
