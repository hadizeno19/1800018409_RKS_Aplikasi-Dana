  <link rel="stylesheet" type="text/css" href="css/login.css">
<div class="login-page">
  <div class="form">
    <form class="login-form" action="prosesdaftar.php" method="post">
    	<h3>REGISTRASI</h3><br/>
      <input type="text" name="nama" id="nama" placeholder="nama"/>
      <input type="text" name="email" id="email" placeholder="email"/>
      <input type="text" name="username" id="username" placeholder="username"/>
      <input type="password" name="password" id="password" placeholder="password"/>
      <button>DAFTAR</button>
      <p class="message">Sudah Punya Akun? <a href="login.php">LOGIN!!</a></p>
      <p class="message">Kembali Ke <a href="dashboard.php">Beranda</a></p>
    </form>
  </div>
</div>
<script type="text/javascript" src="js/login.js"></script>